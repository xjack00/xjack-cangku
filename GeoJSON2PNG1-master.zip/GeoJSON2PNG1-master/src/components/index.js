
module.exports = {
    loop: require('./loop'),
    square: require('./square'),
    circle: require('./circle'),
    line: require('./line'),
    polyline: require('./polyline'),
    keyboard: require('./keyboard'),
    svg: require('./svg'),
    path: require('./path'),
    force: require('./force'),
    collider: require('./collider')
};
