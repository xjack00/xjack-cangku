
What's GeoJSON2PNG
GeoJSON2PNG is a GeoJSON to PNG converter playground.

Interactions
Drag and drop a GeoJSON file* (supported only Polygon and MultiPolygon geometries)
Click on START to initialize a new game session
Move your feature (grey feature named player)
- press [W] or [Arrow Up] to move UP
- press [A] or [Arrow Left] to move LEFT
- press [D] or [Arrow Right] to move RIGHT
Jump on top of a feature to catch it
Retrieve your PNG file at the end of game session from PNG box
* If you have not a GeoJSON file you can try the game by clicking on PRACTICE